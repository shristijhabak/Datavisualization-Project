/*----------------------------------------------------
  |                                                  |     
  |         MAdistrictMAP                            | 
  |                                                  | 
------------------------------------------------------*/
    

    d3.json("https://cdn.rawgit.com/dakoop/e3d0b2100c6b6774554dddb0947f2b67/raw/ea38ad2f7949fb5c2242fa1571c9ea12140f2a76/ma-school-districts-500.geojson",function(err, geoData) {

        var width=900;
        var height=510;

        var district=d3.select("#MAdistrictMAP").append("svg").attr('width',width).attr('height',height);
                
        var projectionVal=d3.geoConicConformal().scale(9999+1)
                .parallels([41.7166667, 42.6833333])
                .rotate([71.5, 0]);

        var pathValues=d3.geoPath().projection(projectionVal)      

        var opacityValues=[];

          for(i=1;i<=8;i++)
              opacityValues.push('0.'+i);
      
         var colorValues=[];      
              colorValues[0]="Charter - Horace Mann";
              colorValues[1]="Charter - Commonwealth";
              colorValues[2]="Regional Academic";
              colorValues[3]="Local School";
              colorValues[4]="Independent Vocational";
              colorValues[5]="Independent Public";
              colorValues[6]="County Agricultural";
              colorValues[7]="Regional Vocational Technical";              

        var colorSetter=d3.scaleOrdinal().range(opacityValues);   
            colorSetter.domain(colorValues);      

        var arrangeY=100;
        //-------------For Extra Credit , legends are there
        var legds = district.append("g")
                      .attr("font-size", 10)
                      .attr("text-anchor", "end")
                      .selectAll("g")
                      .data(colorValues)
                      .enter().append("g")

                      legds.append("rect")
                          .attr("height", '5')
                          .attr('width','10')
                          .attr('fill','magenta')
                          .attr("x",width/2-300 )
                          .attr("y", function(d,i){return width/2-arrangeY+(i*10) } )
                          .attr('stroke','black')
                          .attr('style',function(d){
                            return 'opacity:'+colorSetter(d)
                          })
          
          var xdiv=160;
                            
                      legds.append("text")
                          .attr("dy", "0.29em")
                          .attr("x",width/2-xdiv )
                          .text(function(v) { return v; })
                          .attr("y", function(d,i){return width/2-arrangeY+(i*10)} )

          district.selectAll('path')
              .data(geoData.features).enter()
              .append('path')
              .attr('d',pathValues)
              .attr('style',function(val){ return 'opacity:'+colorSetter(val.properties.MADISTTYPE) })
              .attr('transform','translate(0,'+(7999+1)+')') 
              .attr('stroke','black')
              .attr('fill','magenta')                

    })




/*----------------------------------------------------
  |                                                  |     
  |               LocalMAP/RegionalMAP               | 
  |                                                  | 
------------------------------------------------------*/

    function spendingPupil(divId,tyofMap){
          function PupilMap(err, geoData, sValues) {
              var w = 820;
              var h = 420;

              var tpvalues=sValues.map(function(spend){
                          return +spend.TTPP;          // Fill missing values with 0 and convert string to intger
              })
              var domainChain=d3.extent(tpvalues); 
              
              var graph = d3.select(divId).append("svg").attr('width',w).attr('height',h)
          
              var projectionVal=d3.geoConicConformal().scale(9999+1)
                .parallels([41.7166667, 42.6833333])
                .rotate([71.5, 0]);

              var path=d3.geoPath().projection(projectionVal)      
                
              var opacityValues=[];

              for(i=1;i<=8;i++)
                  opacityValues.push('0.'+i);
      
              var colorSetter = d3.scaleOrdinal().range(opacityValues);
          
              colorSetter.domain(domainChain);

              graph.selectAll('path')
                      .data(geoData.features)
                      .enter()
                      .append('path')
                      .attr('d',path)
                      .attr('style',function(d){
                              if(d.properties.MADISTTYPE==tyofMap) {
                                var id=d.properties.ORG_CODE/10000; 
                                for(let v of sValues)
                                    if(v.LEA==id)
                                          return 'fill:magenta;'+'; opacity: '+colorSetter(v['TTPP'])
                              }
                              return 'fill:none';
                      })
                      .attr('stroke','black')
                      .attr('transform','translate(0,'+(7999+1)+')') 

                 var legValues=[];
                 legValues.unshift(0);
                 legValues.unshift(11320);
                 legValues.unshift(12320);
                 legValues.unshift(13320);
                 legValues.unshift(14420);

                      
                 var leg=graph.append("g")
                      .attr("font-size", 10)
                      .selectAll("g")
                      .data(legValues)
                      .enter().append("g")

                  var yAdj=99,x2=210;      
                      leg.append("text")
                          .text(function(v) { return v })
                          .attr("dy", "0.29em")
                          .attr("x",w/2-x2 )
                          .attr("y", function(d,i){return w/2-yAdj+(i*10)} )

                  var xAdj=100,x1=170;        
                      leg.append("rect")
                          .attr("x",w/2-x1 )
                          .attr("y", function(d,i){return w/2-xAdj+(i*10) } )
                          .attr("height", '7')
                          .attr('width','11')
                          .attr('stroke','black')
                          .attr('style',function(v){
                            return (v==0)? 'fill:none' : 'fill:magenta;'+'; opacity: '+colorSetter(v)
                          })

              }

              d3.queue()
                .defer(d3.json, "https://cdn.rawgit.com/dakoop/e3d0b2100c6b6774554dddb0947f2b67/raw/ea38ad2f7949fb5c2242fa1571c9ea12140f2a76/ma-school-districts-500.geojson")
                .defer(d3.csv, "https://gist.githubusercontent.com/dakoop/e3d0b2100c6b6774554dddb0947f2b67/raw/b88ded9fbc37a4e13e7f94d58a79efe2074c8c8a/ma-school-funding.csv")
                .await(PupilMap);    

    }

    spendingPupil('#RegionalMAP','Regional Academic');
    spendingPupil('#LocalMAP','Local School');

/*----------------------------------------------------
  |                                                  |     
  |               leafleftMAP                        | 
  |                                                  | 
------------------------------------------------------*/
    
    //-------------- For Extra Credit-------------
    function changeValues(select){
            featurePath.attr("d",path).attr('style',function(d){ return (d.properties.MADISTTYPE==select.value)? 'fill:magenta;'+'; opacity:0.6'  :  'fill:none' })
    }    

    function leafleftMap(id,type){

        function projectPoint(x, y) {
          var p = leafleft.latLngToLayerPoint(new L.LatLng(y, x));
          this.stream.point(p.x, p.y);
        }

        let mapLink="http://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png";

        let posObject={       
                          center: [42.313598, -71.345686], 
                          zoom: 8
                    };

        let leafleft = new L.Map(id,posObject)
                            .addLayer(new L.TileLayer(mapLink));

        let graph = d3.select(leafleft.getPanes().overlayPane).append("svg");
        let graphElement = graph.append("g").attr("class", "leaflet-zoom-hide"); //defined in leafleft.css
          
        d3.json("https://cdn.rawgit.com/dakoop/e3d0b2100c6b6774554dddb0947f2b67/raw/ea38ad2f7949fb5c2242fa1571c9ea12140f2a76/ma-school-districts-500.geojson", function(geoData) {

              function newPath() {
                  var bound = path.bounds(geoData);
                  var tL = bound[0],bR = bound[1];
                  var a=tL[0];
                  var b=tL[1];
                  graph.style("top", b + "px")
                    .style("left", a + "px")
                    .attr("height", bR[1] - b)
                    .attr("width", bR[0] - a)
                    graphElement.attr("transform", "translate(" + -a + "," + -b + ")");
                    featurePath.attr("d",path)
              }

              leafleft.on("viewreset", newPath);   //Attaching event on zooming

              var transform = d3.geoTransform({point:projectPoint});
                  path = d3.geoPath().projection(transform);

              featurePath = graphElement.selectAll("path").data(geoData.features).enter().append("path").attr('stroke','black')
                                .attr('style',function(d){
                                     return (d.properties.MADISTTYPE==type)? 'fill:magenta;'+'; opacity:0.6'  :  'fill:none';
                                })
              
              newPath();
        })
    }

    leafleftMap("leafleftMAP",'Regional Academic');
    