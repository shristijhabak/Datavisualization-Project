The size of dataset is 120MB so I used local server to run the project.

Link to dataset which I used is attached in index.html file.
