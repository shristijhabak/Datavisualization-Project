(function () {
    'use strict';

    var statesWithNames = [
        {
          state : 'Alabama',
          code : 'AL'
        },
        {
          state : 'Alaska',
          code : 'AK'
        },
        {
          state : 'American Samoa',
          code : 'AS'
        },
        {
          state : 'Arizona',
          code : 'AZ'
        },
        {
          state : 'Arkansas',
          code : 'AR'
        },
        {
          state : 'California',
          code : 'CA'
        },
        {
          state : 'Colorado',
          code : 'CO'
        },
        {
          state : 'Connecticut',
          code : 'CT'
        },
        {
          state : 'Delaware',
          code : 'DE'
        },
        {
          state : 'Dist. of Columbia',
          code : 'DC'
        },
        {
          state : 'Florida',
          code : 'FL'
        },
        {
          state : 'Georgia',
          code : 'GA'
        },
        {
          state : 'Guam',
          code : 'GU'
        },
        {
          state : 'Hawaii',
          code : 'HI'
        },
        {
          state : 'Idaho',
          code : 'ID'
        },
        {
          state : 'Illinois',
          code : 'IL'
        },
        {
          state : 'Indiana',
          code : 'IN'
        },
        {
          state : 'Iowa',
          code : 'IA'
        },
        {
          state : 'Kansas',
          code : 'KS'
        },
        {
          state : 'Kentucky',
          code : 'KY'
        },
        {
          state : 'Louisiana',
          code : 'LA'
        },
        {
          state : 'Maine',
          code : 'ME'
        },
        {
          state : 'Maryland',
          code : 'MD'
        },
        {
          state : 'Marshall Islands',
          code : 'MH'
        },
        {
          state : 'Massachusetts',
          code : 'MA'
        },
        {
          state : 'Michigan',
          code : 'MI'
        },
        {
          state : 'Micronesia',
          code : 'FM'
        },
        {
          state : 'Minnesota',
          code : 'MN'
        },
        {
          state : 'Mississippi',
          code : 'MS'
        },
        {
          state : 'Missouri',
          code : 'MO'
        },
        {
          state : 'Montana',
          code : 'MT'
        },
        {
          state : 'Nebraska',
          code : 'NE'
        },
        {
          state : 'Nevada',
          code : 'NV'
        },
        {
          state : 'New Hampshire',
          code : 'NH'
        },
        {
          state : 'New Jersey',
          code : 'NJ'
        },
        {
          state : 'New Mexico',
          code : 'NM'
        },
        {
          state : 'New York',
          code : 'NY'
        },
        {
          state : 'North Carolina',
          code : 'NC'
        },
        {
          state : 'North Dakota',
          code : 'ND'
        },
        {
          state : 'Northern Marianas',
          code : 'MP'
        },
        {
          state : 'Ohio',
          code : 'OH'
        },
        {
          state : 'Oklahoma',
          code : 'OK'
        },
        {
          state : 'Oregon',
          code : 'OR'
        },
        {
          state : 'Palau',
          code : 'PW'
        },
        {
          state : 'Pennsylvania',
          code : 'PA'
        },
        {
          state : 'Puerto Rico',
          code : 'PR'
        },
        {
          state : 'Rhode Island',
          code : 'RI'
        },
        {
          state : 'South Carolina',
          code : 'SC'
        },
        {
          state : 'South Dakota',
          code : 'SD'
        },
        {
          state : 'Tennessee',
          code : 'TN'
        },
        {
          state : 'Texas',
          code : 'TX'
        },
        {
          state : 'Utah',
          code : 'UT'
        },
        {
          state : 'Vermont',
          code : 'VT'
        },
        {
          state : 'Virginia',
          code : 'VA'
        },
        {
          state : 'Virgin Islands',
          code : 'VI'
        },
        {
          state : 'Washington',
          code : 'WA'
        },
        {
          state : 'West Virginia',
          code : 'WV'
        },
        {
          state : 'Wisconsin',
          code : 'WI'
        },
        {
          state : 'Wyoming',
          code : 'WY'
        }
    ];

    const
      d3 = window.d3;

    function GeoMap(tilegram, data, model) {

      const

        GEO_MAP_ELEMENT = "#sc-geo-map",
        GEO_MAP_WIDTH = 500,
        GEO_MAP_HEIGHT = 300,

        svg = d3.select(GEO_MAP_ELEMENT)
        .append("svg")
        .attr("preserveAspectRatio", "xMinYMin meet")
        .attr("viewBox", `0 0 ${GEO_MAP_WIDTH} ${GEO_MAP_HEIGHT}`)
        //class to make it responsive
        .classed("svg-content-responsive", true),
        //.append("svg").attr('width', GEO_MAP_WIDTH).attr('height', GEO_MAP_HEIGHT);


        tiles = topojson.feature(tilegram, tilegram.objects.tiles),

        transform = d3.geoTransform({
          point: function point(x, y) {
            return this.stream.point(x, -y)
          }
        }),

        path = d3.geoPath().projection(transform),

        //852, 492 actual hesagon geo size
        scale = 0.54, // ration with a little tweak

        g = svg.append('g')
        .attr('transform', 'translate(-190,' + (GEO_MAP_HEIGHT - 8) + ') scale(' + scale + ')'),

        // build list of state codes
        stateCodes = [],
        // build list of state names
        stateNames = [],
        // build a list of colour values
        countValues = [];

      let

        borders;


      model.registerModeHandler(update);

      function showTiles(tilegram, data, model) {


        tilegram.objects.tiles.geometries.forEach(geometry => {

          if (stateCodes.indexOf(geometry.properties.state) === -1) {

            let

              dataElement = data.find(
                element => element.key === geometry.properties.state
              );

            stateCodes.push(geometry.properties.state);

            stateNames.push(dataElement ? dataElement.state : "");

            countValues.push(dataElement ? dataElement.count : "255");

          }

        });

        g.on('mouseout', () => {
          model.setState();
        });

        //Understand this
        borders = g.selectAll('.tiles')
          .data(tiles.features)
          .enter().append('path')
          .attr('d', path)
          .attr('class', 'border');

        borders
          .attr('fill', (d, i) => {
            return model.colorForStateAndMode(d.properties.state)
            //return linear(countValues[i]);
          })
          .attr('stroke', '#130C0E').attr('stroke-width', 4);

        borders.on('click', (d, i) => {
          console.log('d', d);
          console.log('stateCodes[i]', stateCodes[i]);
          console.log('stateNames[i]', stateNames[i]);
        });

        borders.on('mouseover', (d, i) => {
          model.setState(stateCodes[i]);
        });

        // add some labels
        g.selectAll('.state-label')
          .data(tiles.features).enter()
          .append('text')
          .attr('class', d => 'state-label state-label-' + d.id)
          .attr('transform', d => 'translate(' + path.centroid(d) + ')')
          .attr('dy', '.35em')
          // .attr('dx', '10px')
          .text(d => d.properties.state);

      }

      function update() {
        borders
          .attr('fill', (d, i) => {
            return model.colorForStateAndMode(d.properties.state)
            //return linear(countValues[i]);
          })
          .attr('stroke', '#130C0E').attr('stroke-width', 4);
      }

      showTiles(tilegram, data, model);
      update(model.mode);

    }

    const
      d3$1 = window.d3;

    function PPMKey(data, model) {

      const
        PPM_KEY_ELEMENT = "#sc-ppm-key",
        PPM_WIDTH = 600,
        PPM_HEIGHT = 600,
        svg = d3$1.select(PPM_KEY_ELEMENT)
        .append("svg")
        .attr("preserveAspectRatio", "xMinYMin meet")
        .attr("viewBox", `0 0 ${PPM_WIDTH} ${PPM_HEIGHT}`)
        .classed("svg-content-responsive", true),

        thresholds = d3$1.ticks(30000, 150000, 5),

        histogram = d3$1.histogram()
        .value(d => d.count)
        .domain([0, 150000]) // Passing in nice domain from x [0, 55000]
        .thresholds(thresholds),

        bins = histogram(data);

      model.registerModeHandler(update);

      function getKeyData(mode) {

        if(mode === model.MODE_COMPLAINT) {
          return bins.map(bin => {
            return {
              length: bin.length,
              label: `≤${bin.x1}`,
              fill: model.complaintColor(bin.x1)
            }
          })
        }

        if(mode === model.MODE_PRODUCT) {
          return model.products.map(product => {
            return {
              length: product.value,
              label: product.key,
              fill: model.productColor(product.key)
            }
          })
        }
      }

      function getKeyTitle(mode) {

        if(mode === model.MODE_COMPLAINT) {
          return "Complaints Per 150,000"
        }

        if(mode === model.MODE_PRODUCT) {
          return "Complaints for Product"
        }
      }

      function update(mode) {

        $('#sc-complaints-ppm').text(getKeyTitle(mode));

        let keyData = getKeyData(mode);

        svg.selectAll(".ppm-key-block").remove();
        draw(keyData);
      }

      function draw(data) {
        var ppmKeyBlocks = svg.selectAll(".ppm-key-block")
          .data(data)
          .enter().append("g")
          .attr("class", "ppm-key-block");

        ppmKeyBlocks
          .append("rect")
          .attr("class", "ppm-key-block-color")
          .attr("transform", (d, i) => `translate(${(PPM_WIDTH / data.length) * i},0)`)
          .attr("width", (d, i) => PPM_WIDTH / data.length)
          .attr("height", d => 30)
          .attr("fill", d => d.fill);

        ppmKeyBlocks
          .append("text")
          .attr("transform", (d, i) => `translate(${(PPM_WIDTH / data.length) * (i + 0.5)}, 50) rotate(90)`)
          .attr("width", (d, i) => PPM_WIDTH / bins.length)
          .attr("class", "ppm-key-block-label")
          .attr("text-anchor", "left")
          .text(d => `(${d.length}) ${d.label}`);
      }

      update(model.mode);

    }

    function GeoInfoPane(data, model) {

      let
        selectedState;

      const

        complaints = [{
            key: 'Web',
            selector: '#complaint-web'
          },
          {
            key: 'Email',
            selector: '#complaint-email'
          },
          {
            key: 'Phone',
            selector: '#complaint-phone'
          },
          {
            key: 'Referral',
            selector: '#complaint-referral'
          },
          {
            key: 'Postal mail',
            selector: '#complaint-postal'
          },
          {
            key: 'Fax',
            selector: '#complaint-fax'
          }
        ],

        container = document.getElementById('sc-complaints-info-state');


      function setNodeValue(node, value) {
        if (!node) {
          return
        }

        while (node.firstChild) {
          node.removeChild(node.firstChild);
        }
        node.appendChild(document.createTextNode(`${value}`));
      }

      function getNodeForValue(container, selector) {
        return container.querySelector(selector)
      }


      function setComplaintValues(container, state, complaints) {

        complaints.forEach(complaint => {
          let submission = state.submissions.find(
            submission => submission.key === complaint.key
          );
          setNodeValue(
            getNodeForValue(container, complaint.selector),
            submission ? submission.value : 0
          );
        });
      }

      function setDetailVisibility(container, state) {
        let detail = getNodeForValue(container, '#sc-complaints-info-state-detail'),
          className = detail.className.replace(/ +?state-detail-hide/g, '');
        if (!state) {
          className = className + ' state-detail-hide';
        }
        detail.className = className;
      }

      function update(newSelectedState) {

        if (selectedState && !newSelectedState) {
          selectedState = newSelectedState;
          setDetailVisibility(container, selectedState);
        }
        if (newSelectedState) {
          if (selectedState && selectedState.key === newSelectedState.key) {
            return
          }

          selectedState = newSelectedState;

          setNodeValue(
            getNodeForValue(container, '#state-name'),
            selectedState.state
          );
          setNodeValue(
            getNodeForValue(container, '#complaint-count'),
            selectedState.count
          );

          setNodeValue(
            getNodeForValue(container, '#complaint-product'),
            selectedState.topProduct
          );

          setComplaintValues(container, selectedState, complaints);
        }

        setDetailVisibility(container, selectedState);

      }

      model.registerStateHandler(
        state => {
          update(state);
        }
      );
    }

    const
      d3$2 = window.d3;

    function Sankeys(data) {

      const

        SANKEY_ELEMENT = "#sc-complaint-sankey",
        SANKEY_WIDTH = 900,
        SANKEY_HEIGHT = 300,

        svg = d3$2.select(SANKEY_ELEMENT)
        .append("svg")
        .attr("preserveAspectRatio", "xMinYMin meet")
        .attr("viewBox", `0 0 ${SANKEY_WIDTH} ${SANKEY_HEIGHT}`)
        //class to make it responsive
        .classed("svg-content-responsive", true),


        formatNumber = d3$2.format(",.0f"),

        format = function(d) {
          return formatNumber(d);
        },

        //path = sankey.link(),
        //
        consentNodes = [{
            name: 'Consent provided'
          },
          {
            name: 'Consent not provided'
          },
          {
            name: 'Other'
          },
          {
            name: 'Consent withdrawn'
          }
        ],

        resolutionNodes = [{
            name: 'Resolved',
            key: 'Yes'
          },
          {
            name: 'Not resolved',
            key: 'No'
          },
          {
            name: 'Not Applicable',
            key: 'N/A'
          }
        ],

        consentIgnores = ['', 'N/A', 'Consent withdrawn'],

        rollup = (field, nextrollup) => v => {
          return nextrollup ? {
            count: v.length,
            values: d3$2.nest()
              .key(d => d[field])
              .rollup((v) => nextrollup(v))
              .entries(v)
          } : {
            count: v.length,
            values: d3$2.nest()
              .key(d => d[field])
              .entries(v)
          }

        },

        sankiesFromData = d3$2.nest()
        .key(d => {
          return d.submissionType
        })
        //.key(d => d.submissionType)
        .key(d => d.consumerConsentProvided)
        .rollup(rollup('consumerDisputed', v => v.length))
        //.key(d => d.consumerDisputed)*/
        //.rollup(v => v.length)
        .entries(data),



        graph = sankiesFromData
        //Remove unwanted consents
        .filter(d => {
          return !consentIgnores.includes(d.key)
        })
        //Create graph
        .reduce(
          (graph, d, ci, c) => {



            function addResolutionLink(sourceIndex, targetIndex, value, graph) {

              if (value !== void 0 && value > 0) {
                graph.links.push({
                  source: sourceIndex,
                  target: targetIndex,
                  value: value
                });
              }
            }

            function processSubmission(node, graph) {

              const

                index = graph.nodes.push({
                  name: node.key
                }) - 1,


                passThroughValues = node.values.filter(v => v.key === "" || v.key === "N/A")
                .reduce((c, v) => {
                  v.value.values.forEach(
                    v => {
                      c[v.key] = c[v.key] || 0;
                      c[v.key] = c[v.key] + v.value;
                    }
                  );
                  return c
                }, {});


              for (let key in passThroughValues) {
                let resolvedIndex = graph.nodes.findIndex(n => key === n.key);
                addResolutionLink(
                  index,
                  resolvedIndex,
                  passThroughValues[key],
                  graph
                );
              }


              node.values
                .filter(v => v.key !== "" && v.key !== "N/A")
                .forEach(
                  v => {

                    let consentIndex = graph.nodes.findIndex(n => n.name === v.key);

                    //console.log('consentIndex : ', node.key, v.key, consentIndex, v.value.count)

                    addResolutionLink(
                      index,
                      consentIndex,
                      v.value.count,
                      graph
                    );

                    v.value.values.forEach(

                      v => {

                        let resolvedIndex = graph.nodes.findIndex(n => n.key === v.key);

                        addResolutionLink(
                          consentIndex,
                          resolvedIndex,
                          v.value,
                          graph
                        );
                      }
                    );
                  }
                );
            }

            processSubmission(d, graph);

            return graph

          }, {
            nodes: [...resolutionNodes, ...consentNodes],
            links: []
          }
        ),

        colorLinear = d3$2.scaleLinear()
        .domain([0, 250000])
        .range(['#e8d42c', '#e86d29']),

        sankey = d3$2.sankey()
        .nodeWidth(36)
        .nodePadding(40)
        .size([SANKEY_WIDTH - 20, SANKEY_HEIGHT - 30])
        .nodes(graph.nodes)
        .links(graph.links);

      let
        link, node;


      /*
      sankey.link = function() {
        var curvature = .5;

        function link(d) {
          var x0 = d.source.x + d.source.dx,
              x1 = d.target.x,
              xi = d3.interpolateNumber(x0, x1),
              x2 = xi(curvature),
              x3 = xi(1 - curvature),
              y0 = d.source.y + d.sy + d.dy / 2,
              y1 = d.target.y + d.ty + d.dy / 2;
          return "M" + x0 + "," + y0
               + "C" + x2 + "," + y0
               + " " + x3 + "," + y1
               + " " + x1 + "," + y1;
        }

        link.curvature = function(_) {
          if (!arguments.length) return curvature;
          curvature = +_;
          return link;
        };

        return link;
      };
       */

      console.log('sankey() : ', sankey());

      /*var svgGroup = svg.append('g')
        .attr('transform', "rotate(10)")*/


      link = svg.append("g").selectAll(".link")
        .attr("fill", "none")
        .attr("stroke", "#000")
        .attr("stroke-opacity", 0.2)
        .data(graph.links)
        .enter().append("g")
        .attr("transform", "translate(10, 20)")
        .attr("class", "link");

      link
        .append("path")
        .attr("d", d3$2.sankeyLinkHorizontal())
        .attr("stroke-width", d => d.width);

      link.append("title")
        .text(d => d.source.name + " → " +
          d.target.name + "\n" + format(d.value));


      node = svg.append("g").selectAll(".node")
        .data(graph.nodes)
        .enter().append("g")
        .attr("class", "node")
        .attr("transform", "translate(10, 20)");

      node
        .append('rect')
        .attr("fill", d => colorLinear(d.value))
        .attr('stroke', '#130C0E').attr('stroke-width', 1)
        .attr('width', d => d.x1 - d.x0)
        .attr('height', d => d.y1 - d.y0)
        .attr("transform", d => "translate(" + d.x0 + "," + d.y0 + ")");

      node
        .append("text")
        .attr("x", d => d.x1)
        .attr("width", 300)
        .attr("y", d => d.y0 - 10)
        .attr("dy", ".35em")
        .attr("text-anchor", "end")
        .attr("transform", null)
        .text(d => d.name)
        .filter(d => d.x1 < SANKEY_WIDTH / 2)
        .attr("text-anchor", "end")
        .attr("x", d => d.x0)
        .attr("text-anchor", "start");

    }

    const
      d3$3 = window.d3;

    function SubmissionStack(data) {

      const

        BAR_STACK_ELEMENT = '#sc-complaint-blocks',
        BAR_STACK_WIDTH = 900,
        BAR_STACK_HEIGHT = 540,

        svg = d3$3.select(BAR_STACK_ELEMENT)
        .append("svg")
        .attr("preserveAspectRatio", "xMinYMin meet")
        .attr("viewBox", `0 0 ${BAR_STACK_WIDTH} ${BAR_STACK_HEIGHT + 20}`)
        //class to make it responsive
        .classed("svg-content-responsive", true),

        mainParent = svg
        .append('g')
        .attr('width', BAR_STACK_WIDTH)
        .attr('height', BAR_STACK_HEIGHT),

        resolvedKeys = ['Resolved', 'Unresolved', 'Not Applicable'],

        resolvedColor = d3$3.scaleOrdinal().range(['green', 'red', 'orange']).domain(resolvedKeys),

        submissionData = d3$3.nest()
        .key(d => d.submissionType)
        .key(d => d.consumerDisputed)
        .rollup(v => v.length)
        .entries(data),

        submissionKeys = submissionData.map(s => s.key),

        values = submissionData.map(s => {
          let cnt = 0;
          s.values.forEach(v => cnt += v.value);
          return cnt
        }),

        valueExtent = d3$3.extent(values),

        obj = submissionData.map(
          s => {

            const
              resolvedValue = s.values.find(v => v.key === 'Yes'),
              unresolvedValue = s.values.find(v => v.key === 'No'),
              naValue = s.values.find(v => v.key === 'N/A');

            return {
              'Submission': s.key,
              'Resolved': resolvedValue ? resolvedValue.value : 0,
              'Unresolved': unresolvedValue ? unresolvedValue.value : 0,
              'Not Applicable': naValue ? naValue.value : 0
            }
          }
        );

      let
        legend, yAxisCord, xValuesBar, bars, xTexts;

      yAxisCord = d3$3.scaleLinear()
        //Get this using extent w=once data is sorted with nest
        .domain([0, valueExtent[1]])
        .range([BAR_STACK_HEIGHT * 0.7, 0])
        .nice();

      xValuesBar = d3$3.scaleBand()
        .domain(submissionKeys)
        .range([0, BAR_STACK_WIDTH - 100])
        .paddingInner(0.05);

      bars = mainParent.append("g")
        .attr("transform", "translate(30, 0)")
        .selectAll("g")
        .data(d3$3.stack().keys(resolvedKeys)(obj))
        .enter().append("g").attr("fill", val => {
          return resolvedColor(val.key);
        })
        .selectAll("rect")
        .data(val => {
          return val;
        });

      /*Bars*/
      bars.enter().append("rect")
        .attr("width", xValuesBar.bandwidth())
        .attr("x", val => xValuesBar(val.data.Submission))
        .attr("y", val => yAxisCord(val[1]) + 4) // 4 to adjust for lift off bottom bar
        .attr("height", val => yAxisCord(val[0]) - yAxisCord(val[1]));

      /*X-AXIS*/
      xTexts = mainParent.append("g")
        .attr("transform", "translate(30," + ((BAR_STACK_HEIGHT * 0.7) + 5) + ")")
        .attr('class', 'prolog')
        .call(d3$3.axisBottom(xValuesBar))
        .selectAll('text');

      xTexts
        .attr('transform', d => 'translate(0, 15) rotate(10, 0, 0)');

      /*Y-AXIS*/
      mainParent.append("g")
        .call(d3$3.axisLeft(yAxisCord).ticks(null, "s"))
        .attr('transform', 'translate(30,' + (yAxisCord(yAxisCord.ticks().pop()) + 5) + ')')
        .append("text")
        .attr("x", 1)
        .attr("y", yAxisCord(yAxisCord.ticks().pop()));

      legend = mainParent.append("g")
        .attr("font-family", "sans-serif")
        .attr("font-size", 10)
        .attr("text-anchor", "end")
        .selectAll("g")
        .data(resolvedKeys)
        .enter().append("g")
        .attr("transform", (val, i) => "translate(0," + (i + 1) * 20 + ")");

      legend.append("rect")
        .attr("x", BAR_STACK_WIDTH - 50)
        .attr("width", 20)
        .attr("height", 20)
        .attr("fill", resolvedColor);

      legend.append("text")
        .attr("x", BAR_STACK_WIDTH - 60)
        .attr("y", 9.0)
        .attr("dy", "0.30em")
        .text(val => val);

    }

    const
      d3$4 = window.d3;

    function SubmissionRange(data) {

      const
        S_RANGE_ELEMENT = "#sc-complaint-percentage",
        S_RANGE_WIDTH = 900,
        S_RANGE_HEIGHT = 300,

        svg = d3$4.select(S_RANGE_ELEMENT)
        .append("svg")
        .attr("preserveAspectRatio", "xMinYMin meet")
        .attr("viewBox", `0 0 ${S_RANGE_WIDTH} ${S_RANGE_HEIGHT}`)
        //class to make it responsive
        .classed("svg-content-responsive", true),

        rangeData = d3$4.nest()
        .key(d => d.submissionType)
        .rollup(v => v.length)
        .entries(data),

        total = d3$4.sum(rangeData.map(st => st.value)),

        rangeBarData = rangeData.reduce((sts, st, i, array) => {
          sts.push({
            ...st,
            d0: i === 0 ? 0 : sts[i - 1].d1,
            d1: i === 0 ? st.value : sts[i - 1].d1 + st.value
          });
          return sts
        }, []),

        extent = [0, total],

        percScale = d3$4.scaleLinear()
        .domain(extent)
        .range([0, S_RANGE_WIDTH]),

        keys = ['Referral', 'Web', 'Phone', 'Postal mail', 'Email', 'Fax'],

        companyColor = d3$4.scaleOrdinal().range(['red', 'blue', 'green', 'yellow', 'pink', 'orange']).domain(keys),

        bars = svg.append("g")
        .selectAll("g")
        .data(rangeBarData)
        .enter()
        .append("rect")
        .attr("fill", d => companyColor(d.key))
        .attr("width", d => {
          return percScale(d.value)
        })
        .attr("x", d => percScale(d.d0))
        .attr("height", 40);
      //.attr("transform", "translate("+ +"")



      console.log('rangeData : ', rangeData);
      console.log('extent : ', extent);
      console.log('widthScale : ', percScale(200));
      console.log('widthScale : ', percScale.domain());
      console.log('Mathlog : ', Math.log10(total));

    }

    //global.$ = $ = juery

    const
      chroma = window.chroma,
      d3$5 = window.d3,
      f = d3$5.format(".1f"),
      $$1 = window.jQuery = window.jquery = window.$ = jQuery;


    function SwitchButton(state) {

      const
        button = $$1('#switchButton');

      let
        mode = state.mode;

      button.on('click', (e) => {

        if (mode === state.MODE_COMPLAINT) {
          return state.setMode(state.MODE_PRODUCT)
        }
        if (mode === state.MODE_PRODUCT) {
          return state.setMode(state.MODE_COMPLAINT)
        }
      });

      state.registerModeHandler(newMode => {

        let label = 'Unknown';

        if (newMode !== mode) {
          mode = newMode;
          if (mode === state.MODE_COMPLAINT) {
            label = 'Show Product Complaints';
          }
          if (mode === state.MODE_PRODUCT) {
            label = 'Show Top Complaints';
          }
          setButtonLabel(label);
        }
      });

      function setButtonLabel(label) {
        button.text(label);
      }

    }

    function StateModel(geoData, data) {

      const

        MODE_COMPLAINT = 'MODE_COMPLAINT',
        MODE_PRODUCT = 'MODE_PRODUCT',

        products = d3$5.nest()
        .key(d => d.product)
        .rollup(v => v.length)
        .entries(data),

        submissionTypes = d3$5.nest()
        .key(d => d.submissionType)
        .rollup(v => v.length)
        .entries(data),

        productColors = chroma.scale(['#0fcc13', '#52cccb', '#2c48cc'])
        .mode('lch').colors(products.length),

        productNames = products.map(p => p.key),

        productColor = d3$5.scaleOrdinal()
        .domain(productNames)
        .range(productColors),

        complaintColor = d3$5.scaleLinear()
        .domain([0, 200000])
        .range(['#e8d42c', '#e86d29', '#ec530d']),

        modeChangeHandlers = [],
        stateChangeHandlers = [];


      let
        state,
        selectedState,
        mode = MODE_COMPLAINT;

       state = {

          MODE_COMPLAINT,
          MODE_PRODUCT,

          colorForStateAndMode(state) {
            return color(findState(state))
          },

          products,
          productNames,
          submissionTypes,

          productColor,
          complaintColor,
          mode,

          setState(stateCode) {
            selectedState = findState(stateCode);
            notifyStateChange();
          },
          setMode(newMode) {
            mode = newMode;
            notifyModeChange();
          },
          registerModeHandler(handler) {
            modeChangeHandlers.push(handler);
          },
          registerStateHandler(handler) {
            stateChangeHandlers.push(handler);
          }

        };

      function color(state) {
        if (mode == MODE_COMPLAINT) {
          return complaintColor(state.count)
        }
        if (mode == MODE_PRODUCT) {
          return productColor(state.topProduct)
        }
      }

      function notifyModeChange() {
        modeChangeHandlers.forEach(handler => handler(mode));
      }

      function notifyStateChange() {
        stateChangeHandlers.forEach(handler => handler(selectedState));
      }

      function findState(stateCode) {
        return geoData.find(
          state => state.key === stateCode
        )
      }

      return state
    }

    function App(err, tiles, data) {

      if (err) {
        throw new Error('D3 could not load the data, error : ', err)
      }

      //We will next / derive the data need befor construction of any views

      const

        stateCounts = d3$5.nest()
        .key(d => d.state)
        .rollup(v => v.length)
        .entries(data),

        stateSubmissionTypeCounts = d3$5.nest()
        .key(d => d.state)
        .key(d => d.submissionType)
        .rollup(v => v.length)
        .entries(data),

        stateProductCounts = d3$5.nest()
        .key(d => d.state)
        .key(d => d.product)
        .rollup(v => v.length)
        .entries(data),

        geoData = statesWithNames.map(st => {

          const

            stateCount = stateCounts.find(
              element => element.key === st.code
            ),

            stateSubmissions = stateSubmissionTypeCounts.find(
              element => element.key === st.code
            ),

            stateProducts = stateProductCounts.find(
              element => element.key === st.code
            );

          return {
            key: st.code,
            state: st.state,
            //If stateCount / stateSubmissions dont exists it means there were no complaints
            count: stateCount ? stateCount.value : 0,
            submissions: stateSubmissions ? stateSubmissions.values : [],
            products: stateProducts ? stateProducts.values : [],
            topProduct: stateProducts ? stateProducts.values.reduce((acc, p) => {
              if (p.value > acc.value) {
                return p
              }
              return acc
            }).key : ""
          }
        }),

        stateModel = StateModel(geoData, data);

      GeoMap(tiles, geoData, stateModel);
      PPMKey(geoData, stateModel);
      GeoInfoPane(geoData, stateModel);
      Sankeys(data);
      SubmissionStack(data);
      SubmissionRange(data);
      SwitchButton(stateModel);
    }

    $$1(document).ready(() => {

      d3$5.queue()
        .defer(d3$5.json, './data/us-tiles-top.json')
        .defer(d3$5.csv, './data/complaints_full_filtered.csv')
        //.defer(d3.csv, './data/complaints_full_filtered_200000.csv')
        //Ranges are too small here
        //.defer(d3.csv, '/data/complaints_full_filtered_slim.csv')
        .await(App);
    });

}());
